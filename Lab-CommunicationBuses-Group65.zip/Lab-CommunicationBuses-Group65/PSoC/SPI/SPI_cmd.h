/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#define MAX_BUF_LENGTH 25U

#define CharTerminator '\n'

#define DoNothing	0
#define TurnOffLed 	'a'
#define TurnOnLed 	'b'
#define GetSWConst  'c'
#define StopSWConst 'd'
#define GetSWStatus 'e'

/* [] END OF FILE */
