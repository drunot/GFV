/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"

int8_t convertToSigned(uint8_t number);
uint8_t getDecimal(uint8_t number);
char8* readFromI2C(uint8_t Address, char8* printString, uint8_t* DataToRead);

/* [] END OF FILE */
