/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"

int8_t convertToSigned(uint8_t number);
uint8_t getDecimal(uint8_t number);
void GetStringToPrint(char* stringToPrint, uint8_t* dataRead);

/* [] END OF FILE */
